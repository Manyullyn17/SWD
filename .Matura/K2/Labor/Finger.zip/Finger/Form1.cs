﻿using System;
// using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
// using System.Linq;
using System.Text;
// using System.Threading.Tasks;
using System.Windows.Forms;
using MV;
using System.IO.Ports;
using System.IO;

namespace Finger
{
  public partial class Form1 : Form
  {
    double _phi1 = 40.0, _phi2 = 20.0, _phi3 = 10.0;
    Pen _pen = new Pen(Color.Red, 4);
    SerialPort _ser;
    BinaryReaderEx _rd;
    BinaryWriterEx _wr;

    public Form1()
    {
      InitializeComponent();
      timer1.Enabled = false;
    }

    protected override void OnLoad(EventArgs e)
    {
      try {
        _ser = new SerialPort("COM4", 500000, Parity.None, 8, StopBits.One);
        _ser.Open();
      }
      catch(Exception ex) {
        _ser = null;
        MessageBox.Show("No COM !!!!");
        return;
      }
      _rd = new BinaryReaderEx(_ser.BaseStream);
      _wr = new BinaryWriterEx(_ser.BaseStream);
      timer1.Interval = 100; timer1.Enabled = true;
      base.OnLoad(e);
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
      timer1.Enabled = false;
      if( _ser!=null && _wr!=null ) {
        _acqChk.Checked = false; OnAcqCheckBox(null, null);
        _ser.Close();
      }
      base.OnFormClosing(e);
    }

    void OnAcqCheckBox(object sender, EventArgs e)
    {
      if (_acqChk.Checked)
        _wr.WrB(1).WrB(1).Flush();
      else
        _wr.WrB(1).WrB(0).Flush();
    }

    void OnTimer(object sender, EventArgs e)
    {
      int id, knr; double val;
      bool doRefresh = false;
      while (_ser.BytesToRead >= 3) {
        id = _ser.ReadByte();
        if (id >= 11 && id <= 20) {
          knr = id - 10; 
          val = _rd.ReadInt16();
          SetAngle(val, knr); doRefresh = true;
        }
        if (id >= 21 && id <= 30) {
          knr = id - 20; 
          val = _rd.ReadSingle();
        }
        if (id == 10) {
          string txt = _rd.ReadCString();
          _msgList.Items.Add(txt);
        }
      }
      if (doRefresh)
        _panel.Invalidate();
    }

    void SetAngle(double aAccVal, int aChanNr)
    {
      double phi = (aAccVal / 1000.0) * 90.0;
      if (aChanNr == 1)
        _phi1 = phi;
      if (aChanNr == 2)
        _phi2 = phi;
    }

    void OnPaint(object sender, PaintEventArgs e)
    {
      const double L1 = 300.0;
      const double L2 = 200.0;
      const double L3 = 100.0;

      Graphics gr = e.Graphics;
      Vect2D p1 = Vect2D.Create(10, _panel.Height/2);
      Vect2D v1 = Vect2D.Create(L1, -_phi1, true); 
      Vect2D p2 = p1 + v1;
      gr.DrawLine(_pen, p1.AsPoint, p2.AsPoint);

      p1 = p2; v1.SetFrom_R_Phi(L2, -_phi2); p2 = p1 + v1;
      gr.DrawLine(_pen, p1.AsPoint, p2.AsPoint);

      p1 = p2; v1.SetFrom_R_Phi(L3, -_phi3); p2 = p1 + v1;
      gr.DrawLine(_pen, p1.AsPoint, p2.AsPoint);
    }

    void OnEditKeyDown(object sender, KeyEventArgs e)
    {
      if( e.KeyCode!=Keys.Return )
        return;
      string[] words = _Ed1.Text.Split(':');
      if (words.Length < 3)
        return;
      _phi1 = double.Parse(words[0]);
      _phi2 = double.Parse(words[1]);
      _phi3 = double.Parse(words[2]);
      _panel.Invalidate();
    }
  }
}
