﻿namespace Finger
{
  partial class Form1
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this._Ed1 = new System.Windows.Forms.TextBox();
      this._acqChk = new System.Windows.Forms.CheckBox();
      this._panel = new Finger.GridPanel();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this._msgList = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // _Ed1
      // 
      this._Ed1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this._Ed1.Location = new System.Drawing.Point(25, 12);
      this._Ed1.Name = "_Ed1";
      this._Ed1.Size = new System.Drawing.Size(130, 26);
      this._Ed1.TabIndex = 1;
      this._Ed1.Text = "40:20:10";
      this._Ed1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnEditKeyDown);
      // 
      // _acqChk
      // 
      this._acqChk.AutoSize = true;
      this._acqChk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this._acqChk.Location = new System.Drawing.Point(213, 17);
      this._acqChk.Name = "_acqChk";
      this._acqChk.Size = new System.Drawing.Size(101, 20);
      this._acqChk.TabIndex = 2;
      this._acqChk.Text = "Acq On/Off";
      this._acqChk.UseVisualStyleBackColor = true;
      this._acqChk.CheckedChanged += new System.EventHandler(this.OnAcqCheckBox);
      // 
      // _panel
      // 
      this._panel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this._panel.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this._panel.Location = new System.Drawing.Point(12, 51);
      this._panel.Name = "_panel";
      this._panel.Size = new System.Drawing.Size(511, 411);
      this._panel.TabIndex = 0;
      this._panel.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);
      // 
      // timer1
      // 
      this.timer1.Tick += new System.EventHandler(this.OnTimer);
      // 
      // _msgList
      // 
      this._msgList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this._msgList.FormattingEnabled = true;
      this._msgList.Location = new System.Drawing.Point(529, 12);
      this._msgList.Name = "_msgList";
      this._msgList.Size = new System.Drawing.Size(143, 446);
      this._msgList.TabIndex = 3;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(675, 474);
      this.Controls.Add(this._msgList);
      this.Controls.Add(this._acqChk);
      this.Controls.Add(this._Ed1);
      this.Controls.Add(this._panel);
      this.Name = "Form1";
      this.Text = "Form1";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private GridPanel _panel;
    private System.Windows.Forms.TextBox _Ed1;
    private System.Windows.Forms.CheckBox _acqChk;
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.ListBox _msgList;
  }
}

