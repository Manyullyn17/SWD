
#include "mbed.h"
#include "Serial_HL.h"
#include "Bertl16.h"
#include "PeriPhWrapper.h"
#include "MotionControl.h"
#include "SpeedPID.h"
#include "MotionControl2.h"
#include "MotorPins.h"

SerialBLK pc(USBTX, USBRX);
SvProtocol ua0(&pc);

int sysFrequ; Timer stw2;

PIDControl pid(0.7E-3, 4E-3, 0.01E-3); // 0.5E-3, 2E-3, 0.01E-3

void CommandHandler();

// 50..1600

int main(void)
{
	boardPow=1;
  AllLedsOff();
  pc.format(8,SerialBLK::None,1); pc.baud(115200); // 115200
  encR.Init(ENC_A, ENC_RISE); encL.Init(ENC_A, ENC_RISE);
  stw2.start();
  ph.InitSysTick(300);
  ua0.SvMessage("SpeedControl1_7"); 
  
  Timer stw; stw.start();
  while(1) {
    CommandHandler();
		if( stw.read_us()>5000 ) { // 200Hz
      stw.reset();
      if( ua0.acqON ) {
        // ua0.WriteSvI16(1, pid.demand);
        ua0.WriteSvI16(1, encR.GetFilt());
				ua0.WriteSvI16(2, encL.GetFilt());
        ua0.WriteSvI16(3, pid.y*1000);
        // ua0.WriteSvI16(2, pid.diff);
        // ua0.WriteSvI16(3, sysFrequ);
      }
    }
  }
  return 1;
}

// int dir=1;
extern "C" {
void SysTick_Handler(void)
{
  sysFrequ=(int)1E6/stw2.read_us(); stw2.reset();
  encR.CalcSpeed(); encL.CalcSpeed();
	if( pid.on ) {
		pid.CalcOneStep(encR.GetFilt());
    mR.SetPow(pid.y);
  }
} 
}


void CommandHandler()
{
  uint8_t cmd;
  if( !pc.IsDataAvail() )
    return;
  cmd = ua0.GetCommand();
  
  if( cmd==2 ) {
    encR.cnt=0;
    encR.Reset();
    ua0.SvMessage("Reset Cnt");
  }
  if( cmd==3 ) {
    int speed = ua0.ReadI16();
		ua0.SvMessage("Set Pow");
		if( !pid.on ) {
			float pow=(float)speed/1000.0;
			pid.y = pow;
			mR.SetPow(pow); mL.SetPow(pow); 
		}
    else
			{ pid.y=0; pid.demand=speed; } 
  }
  if( cmd==4 ) {
    pid.OnOff(ua0.ReadI16());
    if( !pid.on )
      mR.SetPow(0);
    ua0.SvMessage("RGL On/Off");
  }
  
  if( cmd==200 ) {
		ua0.ReadI16(); // read controller-Num
    pid.ReadCOM(&ua0);
    pid.Print(&ua0);
  }
  if( cmd==201 ) {
		ua0.ReadI16(); // read controller-Num
    ua0.WrB(200);
    pid.WriteCOM(&ua0);
    pid.Print(&ua0);
  }
}
















