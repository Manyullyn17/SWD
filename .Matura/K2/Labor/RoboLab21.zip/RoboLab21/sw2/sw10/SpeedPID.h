
#ifndef SpeedPID_h
#define SpeedPID_h

#include "RingBuffer.h"
#include "math.h"

class PIDParam {
	public:
    PIDParam(float aKP, float aKD, float aKI)
    {
      KP=aKP; KD=aKD; KI=aKI; on=0;
    }

    PIDParam(PIDParam& aPid)
    {
      Copy(aPid); on=0;
		}

    void Copy(PIDParam& aPid)
    {
      KP=aPid.KP; KD=aPid.KD; KI=aPid.KI; 
    }
    
    void ReadCOM(SvProtocol* aP)
    {
      KP=aP->ReadF(); KD=aP->ReadF(); KI=aP->ReadF();
    }

    void WriteCOM(SvProtocol* aP)
    {
      aP->WrF(KP).WrF(KD).WrF(KI);
    }
    
    void Print(SvProtocol* aP)
    {
      aP->SvPrintf("Rg:%4f %4f %4f",KP,KD,KI);
    }
	public:
    int16_t on;
    float KP, KD, KI;
};


class PIDControl : public PIDParam {
		static const float MAX_RGL_POW = 0.9;
    static const int MIN_DEMAND = 30;
		RBuff2<int,20> _hist;
	public:
    PIDControl(float aKP, float aKD, float aKI) : 
		PIDParam(aKP,aKD,aKI)
    {
      demand=0; y=0; on=0; diff=0; sum=0;
		}
		
		PIDControl(PIDControl& aPid) : PIDParam(aPid)
    {
      Copy(aPid);
      demand=0; y=0; on=0; diff=0; sum=0;
		}

    void CalcOneStep(int aSensVal)
    {
      _hist.Put(demand);
      int abw = demand-aSensVal;
      diff=abw-z3;
      z3=z2; z2=z1; z1=abw;
			if( fabs(y)<MAX_RGL_POW ) // anti WindUp
				sum += abw;
			y = KP*(float)abw + KD*(float)diff + KI*(float)sum;
      if( y<-MAX_RGL_POW ) y=-MAX_RGL_POW;
      if( y>MAX_RGL_POW ) y=MAX_RGL_POW;
      if( IsHistZero() )
        y = 0;
    }

    int IsHistZero()
    {
      for(int i=0; i<20; i++) {
        if( _hist.buff[i]!=0 )
          return 0;
      }
      return 1;
    }

    void CheckMin(int aSensVal)
    {
      if( demand==0 && aSensVal<MIN_DEMAND && aSensVal>-MIN_DEMAND )
        { y=0; sum=0; }
    }

    void OnOff(int aOn)
      { sum=0; on=aOn; }

		int GetDemandAbs()
		{
			if( demand<0 )
				return -demand;
			return demand;
		}

  public:
    int diff; // differenzierte Regelabweichung
    int sum;  // integrierte Regelabweichung
  public:
		int demand; // Sollwert
    float y; // Stellgr��e
  private:
    int z1, z2, z3;
};


class PIDControlF : public PIDParam {
		static const float MAX_RGL_POW = 0.9;
    static const float MIN_DEMAND = 30;
		RBuff2<float,20> _hist;
	public:
    PIDControlF(float aKP, float aKD, float aKI) : 
		PIDParam(aKP,aKD,aKI)
    {
      demand=0; y=0; on=0; diff=0; sum=0;
		}
		
		PIDControlF(PIDControl& aPid) : PIDParam(aPid)
    {
      Copy(aPid);
      demand=0; y=0; on=0; diff=0; sum=0;
		}

    void CalcOneStep(float aSensVal)
    {
			_hist.Put(demand);
      float abw = demand-aSensVal;
      diff=abw-z3;
      z3=z2; z2=z1; z1=abw;
      sum += abw;
      y = KP*(float)abw + KD*(float)diff + KI*(float)sum;
      if( y<-MAX_RGL_POW ) y=-MAX_RGL_POW;
      if( y>MAX_RGL_POW ) y=MAX_RGL_POW;
      if( IsHistZero() )
        y = 0;
    }

    int IsHistZero()
    {
      for(int i=0; i<20; i++) {
        if( _hist.buff[i]!=0 )
          return 0;
      }
      return 1;
    }

    void CheckMin(int aSensVal)
    {
      if( demand==0 && aSensVal<MIN_DEMAND && aSensVal>-MIN_DEMAND )
        { y=0; sum=0; }
    }

    void OnOff(int aOn)
      { sum=0; on=aOn; }

		float GetDemandAbs()
		{
			if( demand<0 )
				return -demand;
			return demand;
		}

  public:
    float diff; // differenzierte Regelabweichung
    float sum;  // integrierte Regelabweichung
  public:
		float demand; // Sollwert
    float y; // Stellgr��e
  private:
    float z1, z2, z3;
};

#endif

