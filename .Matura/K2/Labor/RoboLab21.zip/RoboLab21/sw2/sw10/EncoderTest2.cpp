
#include "mbed.h"
#include "Serial_HL.h"
#include "Bertl16.h"
#include "PeriPhWrapper.h"
#include "MotionControl.h"
#include "SpeedPID.h"
#include "MotionControl2.h"
#include "MotorPins.h"

SerialBLK pc(USBTX, USBRX);
SvProtocol ua0(&pc);
int sysFrequ; Timer stw2;

void CommandHandler();
// 200..1300
// 6000..10000 ist die Max-Pulswidth
// 928 bei 10kHz
// 10255 bei 300Hz

int main(void)
{
	boardPow=1;
  AllLedsOff();
  pc.format(8,SerialBLK::None,1); pc.baud(115200); // 115200
  encR.Init(ENC_A, ENC_RISE); encL.Init(ENC_A, ENC_RISE);
	stw2.start(); ph.InitSysTick(300);
  ua0.SvMessage("EncoderTest2_3"); 
  
  Timer stw; stw.start();
  while(1) {
    CommandHandler();
		if( stw.read_us()>10000 ) { 
      stw.reset();
      if( ua0.acqON ) {
				ua0.WriteSvI16(1, encL.cnt);
				ua0.WriteSvI16(2, encR.cnt);
				ua0.WriteSV(3, encL.GetFilt());
        // ua0.WriteSV(3, (float)perfCnt);
        // ua0.WriteSvI16(3, sysFrequ);
      }
		}
  }
  return 1;
}


extern "C" {
void SysTick_Handler(void)
{
  sysFrequ=(int)1E6/stw2.read_us(); stw2.reset();
  encR.CalcSpeed(); encL.CalcSpeed();
} 
}


void CommandHandler()
{
  uint8_t cmd;
  if( !pc.IsDataAvail() )
    return;
  cmd = ua0.GetCommand();
  
  if( cmd==2 ) {
		encL.Reset(); encR.Reset();
    ua0.SvMessage("Reset Cnt");
  }
  if( cmd==3 ) {
		float pow = ua0.ReadF();
    mL.SetPow(pow); mR.SetPow(pow);
    ua0.SvMessage("Set Pow");
	}
	
	/* if( cmd==4 ) {
    if( ua0.ReadI16() )
      ph.SwitchAllISR(true);
    else
      ph.SwitchAllISR(false);
    ua0.SvMessage("Ena/Dis IRQ");
  } */
}
















