
#ifndef MotionControl2_h
#define MotionControl2_h

#include "RingBuffer.h"
#include "math.h"

class RateLim {
    static const float F_SAMPLE = 300.0;
  public:
    float in, out;
		int16_t goesUp;
		int16_t on;
  public:
		RateLim(float aRate)
      { in=out=0; on=1; SetRateSec(aRate); }

		void Reset()
			{ in=out=0; }
    
    // 1000V in 300 Ticks = 1000/300
    void SetRateTicks(float aRate)
      { _rate=aRate; }
    
    // eg. 1000     = 1000V/Sec
    // eg. 1000/10  = 1000V/10Sec
    // e.g 1000/0.1 = 1000V/0.1Sec
    void SetRateSec(float aRate)
      { _rate=aRate/F_SAMPLE; }
    
    void CalcOneStep()
    {
			goesUp=0;
			if( !on ) {
				out=in; return;
			}
      if( fabs(out-in)<=_rate ) {
        out=in; return;
      }
			if( in>0 && in>out )
				goesUp=1;
			if( in<0 && in<out )
				goesUp=1;
			if( in>out )
				{ out += _rate; }
      else
				{ out -= _rate; }
		}
  
  private:
    float _rate;
};

// const int MIN_RGL_SPEED = 5;
const int MIN_RGL_SPEED = 30;

void NLControl(RateLim* aLim, PIDControlF* aPId, SpeedEncoder2* aEnc)
{
	/* if( aLim->goesUp && aLim->out>2 && aLim->out<100 )
		{ aPId->y=0.1; aPId->sum=0; } */
	// !! Bei HL RefRobot  <50 !!!!
	if( !aLim->goesUp && aEnc->GetFiltAbs()<MIN_RGL_SPEED && aPId->GetDemandAbs()<MIN_RGL_SPEED )
		{ aPId->y=0; aPId->sum=0; }
	else 
		aPId->CalcOneStep(aEnc->GetFilt());
}


class SyncControl : public PIDParam {
		const float MIN_SYNC_SPEED = 5;
	public:
    SyncControl(SpeedEncoder2* aL, SpeedEncoder2* aR) : 
		PIDParam(30.0,0.0,0.0)
		{
			_encL=aL; _encR=aR;
			on=0; 
		}

		void CalcOneStep(float aLin, float aRin)
		{
			if( !on )
				goto Ret1;
			if( fabs(aLin)<MIN_SYNC_SPEED )
				goto Ret1;
			if( fabs(aRin)<MIN_SYNC_SPEED )
				goto Ret1;
			float diff = _encL->GetCntAbs()-_encR->GetCntAbs();
			diff *= KP;
			if( aLin>=0 )
				{ aLin -= diff; aRin += diff; }
			else
				{ aLin += diff; aRin -= diff; }
			Ret1:
				lout=aLin; rout=aRin;
		}
	public:
		int16_t on;
		float lout, rout;
	private:
		SpeedEncoder2* _encL;
		SpeedEncoder2* _encR;
};



#endif

