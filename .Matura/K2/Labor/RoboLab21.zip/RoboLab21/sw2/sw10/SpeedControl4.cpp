
#include "mbed.h"
#include "Serial_HL.h"
#include "Bertl16.h"
#include "PeriPhWrapper.h"
#include "MotionControl.h"
#include "SpeedPID.h"
#include "MotionControl2.h"
#include "MotorPins.h"

SerialBLK pc(USBTX, USBRX);
SvProtocol ua0(&pc);

int sysFrequ; Timer stw2, stw3;

PIDControlF pidR(0.9E-3, 4E-3, 0.01E-3); // 0.5E-3, 2E-3, 0.01E-3
// 0.7E-3, 4E-3, 0.01E-3
PIDControlF pidL(pidR);
SyncControl sync(&encL, &encR);

RateLim limL(500); // 1000
RateLim limR(500);

void CommandHandler();
void Monitor();
// 50..1600

int main(void)
{
	boardPow=1;
  AllLedsOff();
  pc.format(8,SerialBLK::None,1); pc.baud(115200); // 115200
  encR.Init(ENC_A, ENC_RISE); encL.Init(ENC_A, ENC_RISE);
  stw2.start(); stw3.start();
  pidR.OnOff(1); pidL.OnOff(1);
  ph.InitSysTick(300); 
	ua0.SvMessage("SpeedControl4_1"); 
  
  Timer stw; stw.start(); 
  while(1) {
    CommandHandler();
		Monitor();
	}
  return 1;
}


void Monitor()
{
	if( stw3.read_us()>10000 ) { 
		stw3.reset();
		if( ua0.acqON ) {
			int diff = encL.GetCntAbs()-encR.GetCntAbs();
			ua0.WriteSvI16(1, encL.GetFilt());
			ua0.WriteSvI16(2, encR.GetFilt());
			ua0.WriteSvI16(3, diff);
		}
	}
}


extern "C" {
void SysTick_Handler(void)
{
	sysFrequ=(int)1E6/stw2.read_us(); stw2.reset();
  encR.CalcSpeed();  encL.CalcSpeed();
	if( pidR.on ) {
		//----------------------------------
		limL.CalcOneStep(); limR.CalcOneStep();
		sync.CalcOneStep(limL.out,limR.out);
		pidL.demand=sync.lout; pidR.demand=sync.rout;
		// pidL.demand=limL.out; pidR.demand=limR.out; 
		//----------------------------------
		NLControl(&limL, &pidL, &encL);
		NLControl(&limR, &pidR, &encR);
		mL.SetPow(pidL.y); mR.SetPow(pidR.y);
  }
} 
}


void DistStraight(int aSpeed, int aDist)
{
	// vorhergehende sollSpeed merken
	int vLP=limL.in; int vRP=limR.in;
	encL.cnt=0; encR.cnt=0;
	limL.in=aSpeed; limR.in=aSpeed;
	while(1) {
		if( encL.GetCntAbs()>=aDist && encR.GetCntAbs()>=aDist ) 
			break;
		Monitor();
	}
	limL.in=vLP; limR.in=vRP;
	ua0.SvPrintf("DL:%d DR:%d", encL.GetCntAbs(), encR.GetCntAbs());
}

void Turn(int aSpeed, int aDist)
{
	// vorhergehende sollSpeed merken
	int vLP=limL.in; int vRP=limR.in;
	encL.cnt=0; encR.cnt=0;
	limL.in=aSpeed; limR.in=-aSpeed;
	while(1) {
		if( encL.GetCntAbs()>=aDist && encR.GetCntAbs()>=aDist ) 
			break;
		Monitor();
	}
	limL.in=vLP; limR.in=vRP;
	ua0.SvPrintf("DL:%d DR:%d", encL.GetCntAbs(), encR.GetCntAbs());
}

void DistCurve(int aSpL, int aSpR, int aDistDiff)
{
	// vorhergehende sollSpeed merken
	int vLP=limL.in; int vRP=limR.in;
	encL.cnt=0; encR.cnt=0;
	limL.in=aSpL; limR.in=aSpR; int diff;
	while(1) {
		diff = encL.GetCntAbs() - encR.GetCntAbs();
		if( diff<0 ) diff=-diff;
		if( diff>=aDistDiff ) 
			break;
		Monitor();
	}
	limL.in=vLP; limR.in=vRP;
	ua0.SvPrintf("Diff=%d", diff);
}

void StopRGLOff()
{
	pidR.OnOff(0); pidL.OnOff(0);
	limL.Reset(); limR.Reset();
	mL.SetPow(0); mR.SetPow(0);
}

void RglOn()
{ pidR.OnOff(1); pidL.OnOff(1); }


void CommandHandler()
{
  uint8_t cmd;
  if( !pc.IsDataAvail() )
    return;
  cmd = ua0.GetCommand();
   
  if( cmd==2 ) {
    encR.Reset(); encL.Reset();
    ua0.SvMessage("Reset Cnt");
  }
  if( cmd==3 ) {
		encR.Reset(); encL.Reset(); RglOn();
		limL.in=ua0.ReadI16(); limR.in=ua0.ReadI16();
	}
  if( cmd==4 ) {
    pidR.OnOff(ua0.ReadI16()); pidL.OnOff(pidR.on);
    if( !pidR.on )
      { mR.SetPow(0); mL.SetPow(0); }
    ua0.SvMessage("RGL On/Off");
  }
  if( cmd==5 ) {
    int rt = ua0.ReadI16();
    limL.SetRateSec(rt); limR.SetRateSec(rt);
		ua0.SvPrintf("Rate: %d",rt);
	}
	if( cmd==6 ) {
		int val=ua0.ReadI16(); LedBL1=!val; LedBR1=!val;
		ua0.SvMessage("Set LED");
	}
	if( cmd==7 ) {
		int speed=ua0.ReadI16(); int dist=ua0.ReadI16();
		ua0.SvMessage("Dist"); RglOn();
		DistStraight(speed, dist);
	}
	if( cmd==8 ) {
		int par[3]; for(int i=0; i<3; i++) par[i]=ua0.ReadI16();
		ua0.SvMessage("Curve"); RglOn();
		DistCurve(par[0],par[1],par[2]);
	}
	if( cmd==9 ) {
		StopRGLOff();
	}
	if( cmd==10 ) {
		limL.on=limR.on=ua0.ReadI16();
		ua0.SvMessage("Lim On/Off");
	}
	if( cmd==11 ) {
		encR.Reset(); encL.Reset();
		sync.on=ua0.ReadI16();
		ua0.SvMessage("Sync On/Off");
	}
	if( cmd==12 ) {
		int par[2]; for(int i=0; i<2; i++) par[i]=ua0.ReadI16();
		ua0.SvMessage("Turn"); RglOn();
		Turn(par[0],par[1]);
	}
	
	
	
	if( cmd==200 ) {
		int num=ua0.ReadI16();
		if( num==1 )
			{ pidR.ReadCOM(&ua0); pidL.Copy(pidR); }
		else // num==2
			sync.ReadCOM(&ua0);
    // pidR.Print(&ua0);
		ua0.SvMessage("Set PID");
  }
  if( cmd==201 ) {
		int num=ua0.ReadI16();
		ua0.WrB(200);
		if( num==1 )
			pidR.WriteCOM(&ua0);
		else // num==2
			sync.WriteCOM(&ua0);
		// pidR.Print(&ua0);
		ua0.SvMessage("Get PID");
  }
}
















