
#ifndef MotorPins_h
#define MotorPins_h

Motor mL(P1_19,P2_15,P2_14); Motor mR(P2_19,P2_20,P2_21); // orig
// Motor  mL(P1_19,P2_14,P2_15); Motor mR(P2_19,P2_21,P2_20);
// Motor mL(P1_19,P2_15,P2_14); Motor mR(P2_19,P2_21,P2_20); // Kaier
// Motor mL(P1_19,P2_14,P2_15); Motor mR(P2_19,P2_21,P2_20); // Koller

SpeedEncoder2 encL(P2_7, P2_6); // Kaier
SpeedEncoder2 encR(P0_5, P0_4); // Ext. Port not orig

#endif

