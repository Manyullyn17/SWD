
#ifndef MotionControl_h
#define MotionControl_h

#include "Filters2.h"

const int ENC_A = 1;
const int ENC_B = 2;
const int ENC_RISE = 1;
const int ENC_FALL = 2;

class Encoder {
  public:
    Encoder(PinName sensA, PinName sensB);
    void Init(int aAB, int aRiseFall);
    virtual void ISR_A()
    {
			/* if( _sensA.read() )
        cnt++;
      else
        cnt++; */
			cnt++;
		}
    virtual void ISR_B()
    {
      /* if( _sensB.read() )
        cnt++;
      else
        cnt++; */
      cnt++;
    }
		int GetCntAbs() {
			if( (int)cnt<0 )
				return -(int)cnt;
			return (int)cnt;
		}
  public:
    uint32_t cnt;
  public:
    DigitalIn _sensA; PinName _pinA;
    DigitalIn _sensB; PinName _pinB;
};


Encoder::Encoder(PinName sensA, PinName sensB) :
_sensA(sensA), _sensB(sensB)
{
  _pinA=sensA; _pinB=sensB;
  cnt = 0;
}



Encoder *enc1=0, *enc2=0;

extern "C" {
void PIN_INT0_IRQHandler()
  { ph.ClearPinIntStatus(0); enc1->ISR_A(); }

void PIN_INT1_IRQHandler()
  { ph.ClearPinIntStatus(1); enc1->ISR_B(); }

void PIN_INT2_IRQHandler()
  { ph.ClearPinIntStatus(2); enc2->ISR_A(); }

void PIN_INT3_IRQHandler()
  { ph.ClearPinIntStatus(3); enc2->ISR_B(); }
}

void Encoder::Init(int aAB, int aRiseFall)
{
  if( enc1==0 ) {
    enc1=this;
    if( aAB & ENC_A )
      ph.InitPinInt(GetPort(enc1->_pinA),GetPin(enc1->_pinA),0,aRiseFall);
    if( aAB & ENC_B )
      ph.InitPinInt(GetPort(enc1->_pinB),GetPin(enc1->_pinB),1,aRiseFall);
  }
  else {
    enc2=this;
    if( aAB & ENC_A )
      ph.InitPinInt(GetPort(enc2->_pinA),GetPin(enc2->_pinA),2,aRiseFall);
    if( aAB & ENC_B )
      ph.InitPinInt(GetPort(enc2->_pinB),GetPin(enc2->_pinB),3,aRiseFall);
  }
}


class DirEncoder : public Encoder {
  public:
    DirEncoder(PinName sensA, PinName sensB) : Encoder(sensA,sensB) 
    { cntDiff=0; }
    
    virtual void ISR_A()
    {
      if( _sensA.read() ) {
        if( _sensB.read() )
          cnt++;
        else
          cnt--;
      }
      else {
        if( _sensB.read() )
          cnt--;
        else
          cnt++;
      }
    }

    virtual void ISR_B()
    {
      if( _sensB.read() ) {
        if( _sensA.read() )
          cnt--;
        else
          cnt++;
      }
      else {
        if( _sensA.read() )
          cnt++;
        else
          cnt--;
      }
    }

    void CalcDiff()
      { cntDiff=cnt-_prevCnt; _prevCnt=cnt; }
  private:
    int _prevCnt;
  public:
    int cntDiff;
};


class SpeedEncoder : public Encoder {
  public:
    static const uint32_t FREQU_FACT = 1E6/2;
  public:
    SpeedEncoder(PinName sensA, PinName sensB) : Encoder(sensA,sensB) 
      { Reset(); }
    void Init(int aAB, int aRiseFall)
      { Encoder::Init(aAB,aRiseFall); _t1.start(); filt.Init(TP_COE_p010); }

    void Reset() { cnt=cntDiff=0; pw=1E7; dir=1; }
    
    virtual void ISR_A()
    {
      if( _sensA.read() ) { 
        pw=_t1.read_us(); _t1.reset();
        if( _sensB.read() ) { cnt++; dir=1; }
        else { cnt--; dir=-1; }
      }
      // cnt++;
    }
    
    virtual void ISR_B()
    {
      cnt++;
    }

		void CalcCntDiff()
			{ cntDiff=cnt-_prevCnt; _prevCnt=cnt; }

    void CalcSpeed() 
    {
			// if( cntDiff==0 )
      if( (_t1.read_us()>25000) || (dir==0) )
        { pw=0xFFFFFFFF; dir=0; }
      filt.CalcOneStep(GetFrequ()<<17);
    }

    int GetFrequ() { return FREQU_FACT/pw; }

    int32_t GetFilt() 
    {
      if( dir==0 )
        return 0;
      else if( dir>0 )
        return (filt.yn>>17);
      else
        return -(filt.yn>>17);
    }

		int32_t GetFiltAbs() 
    {
			if( dir==0 )
        return 0;
      return (filt.yn>>17);
		}

  public:
    uint32_t pw; // PulsWidth
    uint32_t cntDiff;
    int16_t dir;
  private:
    Timer _t1;
    uint32_t _prevCnt;
    Tp2Ord filt;
};



class SpeedEncoder2 : public Encoder {
  public:
    // static const float FREQU_FACT = 1E6/2;
		static const float FREQU_FACT = 1E6;
  public:
    SpeedEncoder2(PinName sensA, PinName sensB) : Encoder(sensA,sensB) 
      { Reset(); }
    void Init(int aAB, int aRiseFall)
      { Encoder::Init(aAB,aRiseFall); _t1.start(); filt.Init(TP_COE_p010); }

    void Reset() { cnt=cntDiff=0; pw=1E7; dir=1; }
    
    virtual void ISR_A()
    {
      if( _sensA.read() ) { 
        pw=_t1.read_us(); _t1.reset();
        if( _sensB.read() ) { cnt++; dir=1; }
        else { cnt--; dir=-1; }
      }
      // cnt++;
    }
    
    virtual void ISR_B()
    {
      cnt++;
    }

		void CalcCntDiff()
			{ cntDiff=cnt-_prevCnt; _prevCnt=cnt; }

    void CalcSpeed() 
    {
			// if( cntDiff==0 )
      if( (_t1.read_us()>25000) || (dir==0) )
        { pw=0xFFFFFFFF; dir=0; }
      filt.CalcOneStep(GetFrequ());
    }

    float GetFrequ() { return FREQU_FACT/(float)pw; }

    float GetFilt() 
    {
      if( dir==0 )
        return 0;
      else if( dir>0 )
        return filt.yn;
      else
        return -filt.yn;
		}

		float GetFiltAbs() 
    {
			if( dir==0 )
        return 0;
      return filt.yn;
		}

  public:
    uint32_t pw; // PulsWidth
    uint32_t cntDiff;
    int16_t dir;
  private:
    Timer _t1;
    uint32_t _prevCnt;
    Tp2OrdF filt;
};


#endif




