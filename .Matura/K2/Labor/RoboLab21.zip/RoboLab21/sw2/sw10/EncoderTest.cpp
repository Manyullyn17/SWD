
#include "mbed.h"
#include "Serial_HL.h"
#include "Bertl16.h"
#include "PeriPhWrapper.h"
#include "MotionControl.h"
#include "MotorPins.h"

SerialBLK pc(USBTX, USBRX);
SvProtocol ua0(&pc);

void CommandHandler();
void TimerISR();

int main(void)
{
  boardPow=3;
  AllLedsOff(); 
	pc.format(8,SerialBLK::None,1); pc.baud(115200); // 115200
	LedFL1=1; LedFL2=1; LedFR2=1;
	
	encR.Init(ENC_B, ENC_RISE);
	encL.Init(ENC_B, ENC_RISE);
	// tc.attach(TimerISR, 10.0E-3);
	
	ua0.SvMessage("EncoderTest_1"); 
	
	Timer stw; stw.start();
	Timer stw2; stw2.start();
	while(1) {
		/* if( stw2.read_ms()>5 )
			{ stw2.reset(); TimerISR(); } */
    CommandHandler();
		if( stw.read_ms()>10 ) { 
      stw.reset();
      if( ua0.acqON ) {
				ua0.WriteSvI16(1, encR.cnt);
        ua0.WriteSvI16(2, encL.cnt);
				ua0.WriteSvI16(3, encL.cnt-encR.cnt); 
      }
    }
  }
  return 1;
}

float KP=1.0E-6;
float fwPow=0.0;
int rglOn=0;
void TimerISR()
{
	if( !rglOn )
		return;
	float korr = KP*(float)(encL.cnt-encR.cnt);
	// korr=0;
	mL.SetPow3(fwPow+korr); mR.SetPow3(fwPow-korr);
}

void CommandHandler()
{
  uint8_t cmd;
  if( !pc.IsDataAvail() )
    return;
  cmd = ua0.GetCommand();
  
  if( cmd==2 ) {
		encR.cnt=0; encL.cnt=0;
    ua0.SvMessage("Resewt Cnt");
  }
  if( cmd==3 ) {
		rglOn=0; encR.cnt=0; encL.cnt=0;
		float pow = ua0.ReadF();
		mR.SetPow(pow); mL.SetPow(pow);
    ua0.SvMessage("Set Pow");
  }
	if( cmd==4 ) {
		encR.cnt=0; encL.cnt=0;
		rglOn=1; fwPow=ua0.ReadF();
		ua0.SvMessage("Set RGL");
  }
	if( cmd==5 ) {
		float val=ua0.ReadF();
		if( val!=0.0 )
			KP = val*1E-3;
		ua0.SvPrintf("KP=%1.2f", KP*1E3);
	}
}

void SetPriorities()
{
  // NVIC_SetPriority(TIMER_32_1_IRQn, 3);
	NVIC_SetPriority(PIN_INT0_IRQn, 3); // nur zum Syntax Test
  /* NVIC_SetPriority(FLEX_INT1_IRQn, 2);
  NVIC_SetPriority(FLEX_INT2_IRQn, 2);
  NVIC_SetPriority(FLEX_INT3_IRQn, 2);
  NVIC_SetPriority(FLEX_INT4_IRQn, 2);
  NVIC_SetPriority(FLEX_INT5_IRQn, 2);
  NVIC_SetPriority(FLEX_INT6_IRQn, 2);
  NVIC_SetPriority(FLEX_INT7_IRQn, 2); */
}

/* void SetPriorities()
{
	NVIC_SetPriorityGrouping(0);
	NVIC_SetPriority(TIMER3_IRQn, 3); // Ticker Prio niedriger als
	NVIC_SetPriority(EINT3_IRQn, 2);  // RCIn Prio  siehe Datenblatt LPC1786
} */

















