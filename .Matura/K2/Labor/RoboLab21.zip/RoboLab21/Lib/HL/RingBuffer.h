
#ifndef RingBuffer_h
#define RingBuffer_h

template<class T, uint8_t aN> 
class RBuff2 {
  public:
    T buff[aN];
    static const uint8_t N = aN;
    uint16_t wrIdx, rdIdx;
    uint16_t wrCnt, rdCnt;
  public:
    RBuff2() { }
    
    void Init()
      { wrIdx=rdIdx=wrCnt=rdCnt=0; }

    void Put(T aX) {
      buff[wrIdx]=aX; wrIdx++;
      if( wrIdx>=N ) wrIdx=0;
      wrCnt++;
    }
    
    T Get() {
      T ret;
      ret=buff[rdIdx]; rdIdx++;
      if( rdIdx>=N ) rdIdx=0;
      rdCnt++;
      return ret;
    }
    
    uint16_t GetReadCount()
      { return wrCnt-rdCnt; }
};


template<class T, int aN>
class DelayLine2 {
  public:
		T _buff[aN];
		static const int _N = aN;
		uint32_t _wrIdx, _rdIdx;
  public:
		DelayLine2() { _wrIdx=_N-1; _rdIdx=0; }
		
		void Put(T aX) {
      _buff[_wrIdx]=aX; _wrIdx++;
      if( _wrIdx>=_N ) _wrIdx=0;
    }
    
    int16_t Get() {
      int16_t ret;
      ret=_buff[_rdIdx];
      return ret;
    }
    
    void IncRdIdx() {
      _rdIdx++;
      if( _rdIdx>=_N ) _rdIdx=0;
    }
    
    T GetAt(uint32_t aPos) {
      aPos += _rdIdx;
      if( aPos>=_N ) aPos = aPos - _N;
      return _buff[aPos];
    }
};

#endif

