
#ifndef Filters2_h
#define Filters2_h

// #include "LPC17xx.h"
#include "FixpTools.h"

// in q29 Format
// In and Out in q31 Format
class Tp1Ord {
  public:
    int32_t alpha, beta; // q29 Format
    int32_t yn;
  public:
    void Init() { SetAlpha(0.1); yn=0; }

    void SetAlpha(float aAlpha);

    int32_t CalcOneStep(int32_t aX)
    {
      aX = aX >> 2; // to 1.29
      yn = MUL_1P29(yn,beta) + MUL_1P29(aX,alpha);
      return yn << 2; // to 1.31
    }
    
    // work as PeakFilter for positiv slopes
    int32_t CalcOnePosPeakStep(int32_t aX)
    {
      aX = aX >> 2; // to 1.29
      if( aX < 0 )
        aX = 0;
      if( aX > yn ) {
        yn = aX;
        return yn << 2;
      }
      // else
      yn = MUL_1P29(yn,beta) + MUL_1P29(aX,alpha);
      return yn << 2; // to 1.31
    }
    
    // work as PeakFilter for negative slopes
    int32_t CalcOneNegPeakStep(int32_t aX)
    {
      aX = aX >> 2; // to 1.29
      if( aX > 0 )
        aX = 0;
      if( aX < yn ) {
        yn = aX;
        return yn << 2;
      }
      // else
      yn = MUL_1P29(yn,beta) + MUL_1P29(aX,alpha);
      return yn << 2; // to 1.31
    }

    int32_t GetY()
      { return yn << 2; } // to 1.31
};



#define TP_COE_p100  0.06745527388907,0.13491054777814,0.06745527388907,-1.14298050253990,0.41280159809619
#define TP_COE_p025  0.00554271721028,0.01108543442056,0.00554271721028,-1.77863177782458,0.80080264666571
#define TP_COE_p010  0.00094469184384,0.00188938368768,0.00094469184384,-1.91119706742607,0.91497583480143
#define TP_COE_p05   0.020083365564211,0.040166731128423,0.020083365564211,-1.561018075800718,0.641351538057563
// TP_COE_p05 = 0.05

// In Out and Coeff. in q27 Format
class Tp2Ord {
  public:
    int32_t _b0, _b1, _b2, _a1, _a2;
    int32_t xd1, xd2, yd2;
    int32_t yn;
  public:
    void Init(float b0, float b1, float b2, float a1, float a2);

    int32_t CalcOneStep(int32_t aX)
    {
      int32_t accu;
      accu  = MUL_1P27(aX,  _b0);
      accu += MUL_1P27(xd1, _b1);
      accu += MUL_1P27(xd2, _b2);
      //---------------------------
      accu -= MUL_1P27(yn, _a1); // yd1=yn
      accu -= MUL_1P27(yd2, _a2);
      //---Delays-------
      yd2=yn; yn=accu;
      xd2=xd1; xd1=aX;
      return yn;
    }
};

class Tp2OrdF {
  public:
    float _b0, _b1, _b2, _a1, _a2;
    float xd1, xd2, yd2;
    float yn;
  public:
    void Init(float b0, float b1, float b2, float a1, float a2);

    float CalcOneStep(float aX)
    {
      float accu;
      accu  = aX*_b0 + xd1*_b1 + xd2*_b2
				    - yn*_a1 - yd2*_a2;
			//---Delays-------
      yd2=yn; yn=accu;
      xd2=xd1; xd1=aX;
      return yn;
    }
};


class Tp4Ord {
  public:
    Tp2Ord f1, f2;
  public:
    void Init(float b0, float b1, float b2, float a1, float a2);
    
    int32_t CalcOneStep(int32_t aX)
      { return f2.CalcOneStep(f1.CalcOneStep(aX)); }
};


void Tp2Ord::Init(float b0, float b1, float b2, float a1, float a2)
{
  _b0=To1p27(b0); _b1=To1p27(b1); _b2=To1p27(b2);
  _a1=To1p27(a1); _a2=To1p27(a2);
  xd1=xd2=yd2=yn=0;
}

void Tp2OrdF::Init(float b0, float b1, float b2, float a1, float a2)
{
  _b0=b0; _b1=b1; _b2=b2;
  _a1=a1; _a2=a2;
  xd1=xd2=yd2=yn=0;
}


void Tp4Ord::Init(float b0, float b1, float b2, float a1, float a2)
{
  f1.Init(b0,b1,b2,a1,a2); f2.Init(b0,b1,b2,a1,a2);
}




#endif

