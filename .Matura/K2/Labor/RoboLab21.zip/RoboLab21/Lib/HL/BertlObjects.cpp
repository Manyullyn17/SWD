
BusOut leds(LED1,LED2,LED3,LED4);
// DigitalOut ledBlue(P1_28); // 3 blaue LEDs

// HI slow
// BertlDrive mL(p34, P1_1, P1_0, P1_12); 
// BertlDrive mR(p36, P1_4, P1_3, P1_13);

#ifndef MOT_REV
// ENE faster
//            pwm  fwd   rev   encoder
BertlDrive mL(p34, P1_1, P1_0, P1_12); 
BertlDrive mR(p36, P1_3, P1_4, P1_13);
#endif

#ifdef MOT_REV
BertlDrive mL(p34, P1_0, P1_1, P1_12); 
BertlDrive mR(p36, P1_4, P1_3, P1_13);
#endif

PortEx pex;
UsDistSens us(p21,p22);

//              main=2^0  LS    ENC2^11
BusOut boardPow(p30,      P1_6, P1_7); // B15

// ls5 nur beim Betrl15
// AnalogInHL ls1(p18), ls2(p16), ls3(p19), ls4(p17); // B14
AnalogInHL ls1(p18), ls2(p16), ls3(p20), ls4(p19), ls5(p17); // B15

void InitBertl()
{
	leds=0;
  mL.Init(); mR.Init(); pex.Init();
	pex.useISR=0;
  pex.ClearLeds();
}


