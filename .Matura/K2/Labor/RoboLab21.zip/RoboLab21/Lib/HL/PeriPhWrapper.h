
#ifndef PriPhWrapper_h
#define PriPhWrapper_h

class PeriPhWrapper {
  public:
    void WrBit(int aPort, int aBit, int aOnOff);
    int RdBit(int aPort, int aBit);
    
    void InitPinInt(int aPort, int aPin, int aChan, int aRiseFall);

    // Min = 3Hz
    void InitSysTick(int aFrequ);

    void ClearPinIntStatus(int aChIdx);

    void SwitchAllISR(bool aOn);
};

extern PeriPhWrapper ph;

class DioPin {
  public:
    DioPin(int aPort, int aBit, bool aIsOut);
    
    void Init(int aPort, int aBit, bool aIsOut);

    void Wr(int aVal)
      { *_reg=aVal; }
    
    int Rd()
      { return *_reg; }
  private:
    uint8_t* _reg;
};


#endif

