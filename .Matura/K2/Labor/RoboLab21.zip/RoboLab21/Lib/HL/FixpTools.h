
#ifndef FixpTools_h
#define FixpTools_h

// #include "lpc_types.h"

#define CHECK_FOR_1p0

#define F_1P15 32768
#define F_3P13 8192
#define F_1P31 0x80000000
#define F_1P30 0x40000000
#define F_1P29 0x20000000
#define F_0P32 0xFFFFFFFF
#define F_1P23 0x00800000
#define F_1P27 0x08000000

#define MAX_1P31  2147483647   // 0x7FFFFFFF
#define MIN_1P31 -2147483648   // 0x80000000

#define MAX_INT16  32767
#define MIN_INT16 -32768

#define C_1P31(aVal) (int32_t)((float)(aVal)*F_1P31)

#define C_1P30(aVal) (int32_t)((float)(aVal)*F_1P30)

#define C_1P29(aVal) (int32_t)((float)(aVal)*F_1P29)

#define C_1P27(aVal) (int32_t)((float)(aVal)*F_1P27)

#define C_1P15(aVal) (int16_t)((float)(aVal)*F_1P15)


inline int16_t To3p13(float aVal) // 3.13
{
#ifdef CHECK_FOR_1p0
  if( aVal==8.0 ) return 0x7FFF;
#endif
  return (int16_t)(aVal*F_3P13);
}

inline int16_t To1p15(float aVal) // 1.15
{
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return 0x7FFF;
#endif
  return (int16_t)(aVal*F_1P15);
}

inline int32_t To1p15L(float aVal) // 1.15
{ 
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return 0x00007FFF;
#endif
  return (int32_t)(aVal*F_1P15);
}

inline int32_t To1p31(float aVal) // 1.31
{ 
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return 0x7FFFFFFF;
#endif
  return (int32_t)(aVal*F_1P31);
}

inline int32_t To1p30(float aVal) // 1.30
{ 
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return 0x3FFFFFFF;
#endif
  return (int32_t)(aVal*F_1P30);
}

inline int32_t To1p29(float aVal) // 1.29
{ 
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return 0x1FFFFFFF;
#endif
  return (int32_t)(aVal*F_1P29);
}

inline uint32_t To0p32(float aVal) // 0.32
{ return (uint32_t)(aVal*F_0P32); }

inline int32_t To1p23(float aVal) // 1.23
{ 
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return (F_1P23-1);
#endif
  return (int32_t)(aVal*F_1P23);
}

inline int32_t To1p27(float aVal) // 1.27
{
#ifdef CHECK_FOR_1p0
  if( aVal==1.0 ) return (F_1P27-1);
#endif
  return (int32_t)(aVal*F_1P27);
}


inline float From3p13(int16_t aVal) // 3.13
{ return (float)aVal/F_3P13; }

inline float From1p15(int16_t aVal) // 1.15
{ return (float)aVal/F_1P15; }

inline float From1p15L(int32_t aVal) // 1.15
{ return (float)aVal/F_1P15; }

inline float From1p31(int32_t aVal) // 1.31
{ return (float)aVal/F_1P31; }

inline float From1p30(int32_t aVal) // 1.30
{ return (float)aVal/F_1P30; }

inline float From1p29(int32_t aVal) // 1.29
{ return (float)aVal/F_1P29; }

inline float From0p32(uint32_t aVal) // 0.32
{ return (float)aVal/F_0P32; }

inline float From1p23(int32_t aVal) // 1.23
{ return (float)aVal/F_1P23; }

inline float From1p27(int32_t aVal) // 1.27
{ return (float)aVal/F_1P27; }


inline int32_t Conv1p31_Dac10(int32_t aVal)
{ return (aVal >> 22) + 512; }


#define MUL_1P31(aX,aY) (((int64_t)aX * (int64_t)aY) >> 31)

#define MUL_1P30(aX,aY) (((int64_t)aX * (int64_t)aY) >> 30)

#define MUL_1P27(aX,aY) (((int64_t)aX * (int64_t)aY) >> 27)

#define MUL_1P29(aX,aY) (((int64_t)aX * (int64_t)aY) >> 29)

#define MUL_1P31_C(aX,aY) ((int32_t)(((int64_t)aX * (int64_t)aY) >> 31))

#define MUL_32_64(aX,aY) (((int64_t)aX * (int64_t)aY))

#define FIX_MUL16(aX,aY,aSF)  (((int32_t)aX*(int32_t)aY)>>aSF)

#define FIX_MUL16NS(aX,aY)  ((int32_t)aX*(int32_t)aY)



#define M_PI 3.1415926535897932384626433832795

const float RAD_GRAD = 180.0/M_PI;

const int32_t FIXP_2PI = C_1P27(2*M_PI);


#endif

