
#include "chip.h"
#include "system_LPC11U6x.h"
#include "core_cm0plus.h"
#include "PeriPhWrapper.h"
// #include "mbed.h"
// using namespace std;

PeriPhWrapper ph;

void PeriPhWrapper::WrBit(int aPort, int aBit, int aOnOff)
{
  // Chip_GPIO_SetPinState(LPC_GPIO, aPort, aBit, aOnOff);
  LPC_GPIO->B[aPort][aBit] = aOnOff;
}

int PeriPhWrapper::RdBit(int aPort, int aBit)
{
  return LPC_GPIO->B[aPort][aBit];
}


void PeriPhWrapper::InitSysTick(int aFrequ)
{
  SystemCoreClockUpdate();
  SysTick_Config(SystemCoreClock / aFrequ);
}


uint16_t actChan=0;
void PeriPhWrapper::InitPinInt(int aPort, int aPin, int aChan, int aRiseFall)
{
  /* We'll use an optional IOCON filter (0) with a divider of 64 for the
	   input pin to be used for PININT */
	Chip_Clock_SetIOCONFiltClockDiv(0, 2); // 64
	// Chip_Clock_SetIOCONFiltClockDiv(0, 1); HL
  /* Configure GPIO pin as input */
	Chip_GPIO_SetPinDIRInput(LPC_GPIO, aPort, aPin);

  /* Configure pin as GPIO with pullup and use optional IOCON divider
	   0 with 3 filter clocks for input filtering */
	Chip_IOCON_PinMuxSet(LPC_IOCON, aPort, aPin,
	(IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_CLKDIV(0) | IOCON_S_MODE(3))); // IOCON_S_MODE(3)
	
	/* Enable PININT clock */
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_PINT);
	
	/* Configure interrupt channel for the GPIO pin in SysCon block */
	Chip_SYSCTL_SetPinInterrupt(aChan, aPort, aPin);
	
	/* Configure channel interrupt as edge sensitive and falling edge interrupt */
	Chip_PININT_ClearIntStatus(LPC_PININT, PININTCH(aChan));
	Chip_PININT_SetPinModeEdge(LPC_PININT, PININTCH(aChan));
	
  if( aRiseFall & 2 )
    Chip_PININT_EnableIntLow(LPC_PININT, PININTCH(aChan));
  if( aRiseFall & 1 )
    Chip_PININT_EnableIntHigh(LPC_PININT, PININTCH(aChan)); // HL
	
	/* Enable interrupt in the NVIC */
	NVIC_ClearPendingIRQ((IRQn_Type)(PIN_INT0_IRQn+aChan));
	NVIC_EnableIRQ((IRQn_Type)(PIN_INT0_IRQn+aChan));

  actChan |= (1<<aChan);
}

void PeriPhWrapper::SwitchAllISR(bool aOn)
{
  if( !aOn ) {
    for(int i=0; i<4; i++) {
      if( actChan & (1<<i) )
        NVIC_DisableIRQ((IRQn_Type)(PIN_INT0_IRQn+i));
    }
		NVIC_DisableIRQ((IRQn_Type)SysTick_IRQn);
  }
  else {
    for(int i=0; i<4; i++) {
      if( actChan & (1<<i) )
        NVIC_EnableIRQ((IRQn_Type)(PIN_INT0_IRQn+i));
    }
		NVIC_EnableIRQ((IRQn_Type)SysTick_IRQn);
  }
}

void PeriPhWrapper::ClearPinIntStatus(int aChIdx)
{
  Chip_PININT_ClearIntStatus(LPC_PININT, PININTCH(aChIdx));
}


DioPin::DioPin(int aPort, int aBit, bool aIsOut)
{
  /* Chip_IOCON_PinMuxSet(LPC_IOCON, aPort, aBit,
						 (IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_CLKDIV(0) | IOCON_S_MODE(3))); */
  /* if( aIsOut )
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, aPort, aBit);
  else
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, aPort, aBit); */

   _reg = (uint8_t*)&(LPC_GPIO->B[aPort][aBit]);
}

void DioPin::Init(int aPort, int aBit, bool aIsOut)
{
	/* Chip_IOCON_PinMuxSet(LPC_IOCON, aPort, aBit,
						 (IOCON_FUNC0 | IOCON_MODE_PULLUP)); 
  if( aIsOut )
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, aPort, aBit);
  else
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, aPort, aBit); */ 

   _reg = (uint8_t*)&(LPC_GPIO->B[aPort][aBit]);
}




















