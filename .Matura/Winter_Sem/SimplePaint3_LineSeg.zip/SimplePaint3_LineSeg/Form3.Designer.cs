﻿namespace SimplePaint
{
  partial class Form3
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      this._panel = new System.Windows.Forms.Panel();
      this._dbgLbl = new System.Windows.Forms.Label();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.menueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this._fileName = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.menuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // _panel
      // 
      this._panel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this._panel.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this._panel.Location = new System.Drawing.Point(12, 87);
      this._panel.Name = "_panel";
      this._panel.Size = new System.Drawing.Size(578, 349);
      this._panel.TabIndex = 0;
      this._panel.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPanelPaint);
      this._panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OnPanelMouseDown);
      this._panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.OnPanelMouseMove);
      this._panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.OnPanelMouseUp);
      // 
      // _dbgLbl
      // 
      this._dbgLbl.AutoSize = true;
      this._dbgLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this._dbgLbl.Location = new System.Drawing.Point(24, 52);
      this._dbgLbl.Name = "_dbgLbl";
      this._dbgLbl.Size = new System.Drawing.Size(57, 20);
      this._dbgLbl.TabIndex = 1;
      this._dbgLbl.Text = "label1";
      // 
      // menuStrip1
      // 
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menueToolStripMenuItem});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(602, 29);
      this.menuStrip1.TabIndex = 2;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // menueToolStripMenuItem
      // 
      this.menueToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.saveToolStripMenuItem});
      this.menueToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.menueToolStripMenuItem.Name = "menueToolStripMenuItem";
      this.menueToolStripMenuItem.Size = new System.Drawing.Size(75, 25);
      this.menueToolStripMenuItem.Text = "Menue";
      // 
      // clearToolStripMenuItem
      // 
      this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
      this.clearToolStripMenuItem.Size = new System.Drawing.Size(119, 26);
      this.clearToolStripMenuItem.Text = "Clear";
      this.clearToolStripMenuItem.Click += new System.EventHandler(this.OnMenueClear);
      // 
      // loadToolStripMenuItem
      // 
      this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
      this.loadToolStripMenuItem.Size = new System.Drawing.Size(119, 26);
      this.loadToolStripMenuItem.Text = "Load";
      this.loadToolStripMenuItem.Click += new System.EventHandler(this.OnMenueLoad);
      // 
      // saveToolStripMenuItem
      // 
      this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
      this.saveToolStripMenuItem.Size = new System.Drawing.Size(119, 26);
      this.saveToolStripMenuItem.Text = "Save";
      this.saveToolStripMenuItem.Click += new System.EventHandler(this.OnMenueSave);
      // 
      // _fileName
      // 
      this._fileName.Location = new System.Drawing.Point(267, 52);
      this._fileName.Name = "_fileName";
      this._fileName.Size = new System.Drawing.Size(100, 20);
      this._fileName.TabIndex = 3;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(172, 52);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(89, 20);
      this.label1.TabIndex = 4;
      this.label1.Text = "FileName:";
      // 
      // Form3
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(602, 448);
      this.Controls.Add(this.label1);
      this.Controls.Add(this._fileName);
      this.Controls.Add(this._dbgLbl);
      this.Controls.Add(this._panel);
      this.Controls.Add(this.menuStrip1);
      this.MainMenuStrip = this.menuStrip1;
      this.Name = "Form3";
      this.Text = "Form1";
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Panel _panel;
    private System.Windows.Forms.Label _dbgLbl;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem menueToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
    private System.Windows.Forms.TextBox _fileName;
    private System.Windows.Forms.Label label1;
  }
}

