﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
// using System.Linq;
using System.Text;
// using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

// Figuren sind nicht mehr verbunden
// Stichwort Liniensegmente

namespace SimplePaint
{
  public partial class Form3 : Form
  {
    Brush _br = new SolidBrush(Color.Blue);
    Pen _pen = new Pen(Color.Blue, 2);
    List<LineSeg> _segList = new List<LineSeg>();
    LineSeg _currSeg;

    public Form3()
    {
      InitializeComponent();
      _fileName.Text = "Bild1.txt";
    }

    void OnPanelMouseMove(object sender, MouseEventArgs e)
    {
      _dbgLbl.Text = e.X.ToString() + ":" + e.Y.ToString();
      if (e.Button == MouseButtons.Left)
      {
        Graphics gr = _panel.CreateGraphics();
        gr.FillEllipse(_br, e.X, e.Y, 4, 4);
        // _list.Add(e.Location);
        // Punkt zum momentanen Segment _currSeg hinzufügen
      }
    }

    void OnPanelPaint(object sender, PaintEventArgs e)
    {
      Graphics gr = e.Graphics;
      // Alle Segmente der _segList zeichnen
      /* Point pt1 = new Point();
      
      Point pt2 = pt1;
      for (int i = 0; i < _list.Count - 1; i++)
      {
        pt1 = _list[i];
        pt2 = _list[i + 1];
        gr.DrawLine(_pen, pt1, pt2);
      } */
    }

    void OnMenueClear(object sender, EventArgs e)
    {
      _segList.Clear();
      _panel.Invalidate();
    }

    void OnMenueLoad(object sender, EventArgs e)
    {
      // Fleißaufgabe selber überlegen
      /* StreamReader sr = null;
      try
      {
        sr = new StreamReader(_fileName.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show("File konnte nicht geschrieben werden");
      }

      _list.Clear();
      string txt; string[] words; Point pt = new Point();
      while (!sr.EndOfStream)
      {
        txt = sr.ReadLine();
        words = txt.Split(','); // words[0] "105"
        pt.X = Convert.ToInt32(words[0]);
        pt.Y = Convert.ToInt32(words[1]);
        _list.Add(pt);
      }
      sr.Close();
      _panel.Invalidate(); */
    }

    void OnMenueSave(object sender, EventArgs e)
    {
      // Fleißaufgabe selber überlegen
      /* StreamWriter sw = null;
      try
      {
        sw = new StreamWriter(_fileName.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show("File konnte nicht geschrieben werden");
        return;
      }

      foreach (Point pt in _list)
      {
        sw.WriteLine("{0},{1}", pt.X, pt.Y);
      }
      sw.Close();
      MessageBox.Show("File wurde geschrieben"); */
    }

    void OnPanelMouseUp(object sender, MouseEventArgs e)
    {
      _panel.Invalidate();
    }

    void OnPanelMouseDown(object sender, MouseEventArgs e)
    {
      _currSeg = new LineSeg();
      _segList.Add(_currSeg);
    }


  }

  class LineSeg
  {
    public List<Point> list = new List<Point>();
    Pen _pn = new Pen(Color.Red, 2);

    public void AddPoint(Point aP)
    {
      list.Add(aP);
    }

    public void Draw(Graphics aGr)
    {
      // die Punkteliste list zeichnen
    }
  }

}
