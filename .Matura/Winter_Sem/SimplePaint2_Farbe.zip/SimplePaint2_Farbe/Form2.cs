﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
// using System.Linq;
using System.Text;
// using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

// Farbe ändern

namespace SimplePaint
{
  public partial class Form2 : Form
  {
    SolidBrush _br = new SolidBrush(Color.Blue);
    Pen _pen = new Pen(Color.Blue, 2);
    List<ColPoint> _list = new List<ColPoint>();
   

    public Form2()
    {
      InitializeComponent();
      _fileName.Text = "Bild1.txt";
    }

    void OnPanelMouseMove(object sender, MouseEventArgs e)
    {
      _dbgLbl.Text = e.X.ToString()  + ":" +  e.Y.ToString();
      if ( e.Button==MouseButtons.Left )
      {
        Graphics gr = _panel.CreateGraphics();
        gr.FillEllipse(_br, e.X, e.Y, 4, 4);
        ColPoint cp;
        cp.pt = e.Location; cp.col = _br.Color;
        _list.Add(cp);
      }
    }

    void OnPanelPaint(object sender, PaintEventArgs e)
    {
      Graphics gr = e.Graphics;
      ColPoint pt1;
      ColPoint pt2;
      for (int i=0; i<_list.Count-1; i++)
      {
        pt1 = _list[i];
        pt2 = _list[i+1];
        _pen.Color = pt1.col;
        gr.DrawLine(_pen, pt1.pt, pt2.pt);
      }
    }

    void OnMenueClear(object sender, EventArgs e)
    {
      _list.Clear();
      _panel.Invalidate();
    }

    void OnMenueLoad(object sender, EventArgs e)
    {
      // Bsp für int in Color umwandeln
      int colVal = 12345;
      Color c1 = Color.FromArgb(colVal);
      /* StreamReader sr = null;
      try
      {
        sr = new StreamReader(_fileName.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show("File konnte nicht geschrieben werden");
      }

      _list.Clear();
      string txt; string[] words; Point pt = new Point();
      while( !sr.EndOfStream )
      {
        txt = sr.ReadLine();
        words = txt.Split(','); // words[0] "105"
        pt.X = Convert.ToInt32(words[0]);
        pt.Y = Convert.ToInt32(words[1]);
        _list.Add(pt);
      }
      sr.Close();
      _panel.Invalidate(); */
    }

    void OnMenueSave(object sender, EventArgs e)
    {
      // Bsp für Color in int umwandeln
      Color c1 = Color.Blue;
      int colVal = c1.ToArgb();
      /* StreamWriter sw = null;
      try
      {
        sw = new StreamWriter(_fileName.Text);
      }
      catch (Exception ex)
      {
        MessageBox.Show("File konnte nicht geschrieben werden");
        return;
      }

      foreach (Point pt in _list)
      {
        sw.WriteLine("{0},{1}", pt.X, pt.Y);
      }
      sw.Close();
      MessageBox.Show("File wurde geschrieben"); */
    }

    void OnPanelMouseUp(object sender, MouseEventArgs e)
    {
      _panel.Invalidate();

    }

    void OnMenueColor(object sender, EventArgs e)
    {
      ColorDialog dlg = new ColorDialog();
      dlg.ShowDialog();
      _br.Color = dlg.Color;
    }
  }


  struct ColPoint
  {
    public Point pt;
    public Color col;
  }
}
