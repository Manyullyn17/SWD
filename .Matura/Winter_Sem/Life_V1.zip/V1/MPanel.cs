using System;
// using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

namespace V1
{
  class MPanel : Panel
  {
    public MPanel() : base()
    {
      this.DoubleBuffered = true;
    }
  }
}
