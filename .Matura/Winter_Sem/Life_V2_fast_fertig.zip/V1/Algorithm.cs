using System;
using System.Collections.Generic;
using System.Text;

namespace V1
{
  partial class LifeForm
  {
    // aOld Matrix mit der n-ten Generation
    // aNew Matrix mit der n+1-ten Generation
    void CalcNextGeneration(bool[,] aOld, bool[,] aNew)
    {
      int nbCount;
      for (int i = 0; i < MAX_CELLS; i++)
      {
        for (int j = 0; j < MAX_CELLS; j++)
        {
          nbCount = GetNeighbourCount(i, j);
          if (aOld[i, j] == false) // tote Zelle
          {
            // if (nbCount == 3)
              // aNew[i, j] = true;
          }
          else // lebende Zelle
          {
          }
        }
      }
      m_CC = aOld; // sicherstellen, da� m_CC=aOld ist
    }

    void ClearCells(bool[,] aCells)
    {
      // alle Zellen von aCells auf false
    }

    // cells of m_CC
    void TurnCellOnOff(int aX, int aY)
    {
      int i = aX / CELL_SIZE;
      if (i >= MAX_CELLS)
        return;
      int j = aY / CELL_SIZE;
      if (j >= MAX_CELLS)
        return;
      m_CC[i, j] = !m_CC[i, j];
    }
    
    // cells of m_CC
    int GetNeighbourCount(int i, int j)
    {
      // wieviele lebende Nachbarn hat Cell(i,j)
      int cnt = 0;
      if (ValOf(i - 1, j - 1))
        cnt++;
      return cnt;
    }

    // Ist Cell(i,j) von m_CC on oder off ?
    // mit richtiger Behandlung von i,j<0 und i,j>=MAX_CELLS
    bool ValOf(int i, int j)
    {
      if (i < 0)
        i = MAX_CELLS - 1;
      if (i >= MAX_CELLS)
        i = 0;
      if (j < 0)
        j = MAX_CELLS - 1;
      if (j >= MAX_CELLS)
        j = 0;
      return m_CC[i, j];
    }

  }
}
