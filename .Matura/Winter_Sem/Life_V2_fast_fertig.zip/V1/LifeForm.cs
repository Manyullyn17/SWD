using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace V1
{
  public partial class LifeForm : Form
  {
    #region CONSTANTS
    const int MAX_CELLS = 20;
    const int CELL_SIZE = 30;
    const int C_M = 2; // CellMargin
    #endregion
    
    // 2 Matritzen zur Verwaltung der n'ten und der n+1'ten Generation
    bool[,] m_CA = new bool[MAX_CELLS, MAX_CELLS];
    bool[,] m_CB = new bool[MAX_CELLS, MAX_CELLS];
    bool[,] m_CC; // current ( active ) CellArray n'te Generation

    Pen _pen = new Pen(Color.Red, 1);
    SolidBrush _br = new SolidBrush(Color.Blue);

    public LifeForm()
    {
      InitializeComponent();
      timer1.Interval = 100;
      // zum Testen ein paar Zellen setzen
      m_CA[3, 3] = true; m_CA[3, 4] = true; m_CA[3, 5] = true;
      m_CA[4, 3] = true; m_CA[4, 4] = true; m_CA[4, 5] = true;
      m_CC = m_CA;
    }

    private void OnPanelPaint(object sender, PaintEventArgs e)
    {
      DrawGrid(e.Graphics);
      DrawCells(e.Graphics);
    }

    private void OnPanelMouseDown(object sender, MouseEventArgs e)
    {
      // der Cell Editor
      TurnCellOnOff(e.X, e.Y);
      m_panel.Invalidate();
    }

    // Cells des aktiven Arrays (m_CC) zeichnen
    void DrawCells(Graphics gr)
    {
      int x, y;
      for (int i = 0; i < MAX_CELLS; i++)
      {
        for (int j = 0; j < MAX_CELLS; j++)
        {
          x = i * CELL_SIZE; y = j * CELL_SIZE;
          if ( m_CC[i, j]==true )
            gr.FillRectangle(_br, x+C_M, y+C_M, CELL_SIZE-2*C_M, CELL_SIZE-2*C_M);
        }
      }
    }

    void DrawGrid(Graphics gr)
    {
      // Raster zeichnen
      int XYmax = MAX_CELLS * CELL_SIZE;
      int x, y, i;
      for (i = 0; i <= MAX_CELLS; i++)
      {
        x = i * CELL_SIZE;
        gr.DrawLine(_pen, x, 0, x, XYmax);
      }
      for (i = 0; i <= MAX_CELLS; i++)
      {
        y = i * CELL_SIZE;
        gr.DrawLine(_pen, 0, y, XYmax, y);
      }
    }

    // N�chste Generation berechnen
    private void OnStepButton(object sender, EventArgs e)
    {
      if (m_CC == m_CA)
      {
        ClearCells(m_CB);
        CalcNextGeneration(m_CA, m_CB);
        m_CC = m_CB;
      }
      else
      {
        ClearCells(m_CA);
        CalcNextGeneration(m_CB, m_CA);
        m_CC = m_CA;
      }
      m_panel.Invalidate();
    }

    private void OnTimerChk(object sender, EventArgs e)
    {
      if (timer1.Enabled)
        timer1.Enabled = false;
      else
        timer1.Enabled = true;
    }

    private void OnTimer(object sender, EventArgs e)
    {
      OnStepButton(null, null);
    }

    private void OnClearButton(object sender, EventArgs e)
    {
      ClearCells(m_CA); ClearCells(m_CB);
      m_panel.Invalidate();
    }

  }
}