﻿using System;
// using System.Collections.Generic;
// using System.Linq;
using System.Text;
// using System.Threading.Tasks;

namespace MTime
{
  class Program
  {
    static void Main(string[] args)
    {
      MTime t1, t2;

      t1 = new MTime("t1"); // ein MTime objekt 0:0:0 erzeugen
      t2 = new MTime("t2",2, 30, 15);

      t1.Print(); t2.Print();

      t2.AddMinutes(40); // müsste jetzt 3:10:15 sein
      t2.Print();

      t2.Minute = 22;

      int x3 = t2.Minute;
    }
  }
}
