﻿using System;
// using System.Collections.Generic;
// using System.Linq;
using System.Text;
// using System.Threading.Tasks;

namespace MTime
{

  class MTime
  {
    int _hours;
    int _minutes;
    int _seconds;
    string _name;

    public MTime(string aName)
    {
      _hours = _minutes = _seconds = 0;
      _name = aName;
    }

    public MTime(string aName, int aHours, int aMinutes, int aSeconds)
    {
      _hours = aHours; _minutes = aMinutes; _seconds = aSeconds;
      _name = aName;
    }

    public void AddSeconds(int aSeconds)
    {
      _seconds = _seconds + aSeconds;
      while (_seconds > 60)
      {
        _seconds = _seconds - 60;
        _minutes++;
      }
    }

    public void AddMinutes(int aMinutes)
    {
      // _minutes = _minutes + aMinutes;
      _minutes += aMinutes;
      while (_minutes > 60)
      {
        _minutes = _minutes - 60;
        _hours++;
      }
    }

    public void SetMinutes(int aMinute)
    {
      if (aMinute < 60 && aMinute >= 0)
        _minutes = aMinute;
    }

    // Verhübschung Property
    public int Minute
    {
      set
      {
        if (value < 60 && value >= 0)
          _minutes = value;
      }
      get
      {
        return _minutes;
      }
    }

    public void Print()
    {
      Console.WriteLine("{0}:{1}:{2}:{3}", _name, _hours, _minutes, _seconds);
    }

  }
}
