﻿using System;
using System.Text;


namespace Complex
{
  class Program
  {
    static void Main(string[] args)
    {
      Test1();
    }

    static void Test1()
    {
      Complex a = new Complex(1, 2); // 1 + j*2
      Complex b = new Complex(3, -4); // 3 - j*4
      Complex c = new Complex();

      c = a.Add(b); // Add als Memberfunktion
      // c = a + b + c
      // c = a.Add(b.add(c));
      // c = 3*( a + b ) + 7 +c;
      // c = Complex.Add(a, b);

      c = a + b;

      Console.WriteLine("a={0}", a);
      Console.WriteLine("b={0}", b);
      Console.WriteLine("c={0}", c);
    }

    static void Test2()
    {
      // a = 1 + j*2
      // b = 3 - j*4;

      // c = a*(b + new Complex(5,6)) + a - b;

      // !!!! Mit Verifikation ( selber nachrechnen )

    }
  }
}
