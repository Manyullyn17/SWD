﻿using System;
using System.Text;


namespace Complex
{
  struct Complex
  {
    double _re, _im;

    public Complex(double aRe, double aIm)
    {
      _re = aRe;
      _im = aIm;
    }

    public Complex Add(Complex aB)
    {
      Complex sum;
      sum._re = _re + aB._re;
      sum._im = _im + aB._im;
      return sum;
    }

    public static Complex Add(Complex aA, Complex aB)
    {
      Complex sum;
      sum._re = aA._re + aB._re;
      sum._im = aA._im + aB._im;
      return sum;
    }

    public static Complex operator+(Complex aA, Complex aB)
    {
      Complex sum;
      sum._re = aA._re + aB._re;
      sum._im = aA._im + aB._im;
      return sum;
    }

    public static Complex operator *(Complex aA, Complex aB)
    {
      Complex prod;
      prod._re = 0;
      prod._im = 0;
      return prod;
    }

    public override string ToString()
    {
      if( _im<0 )
        return string.Format("{0} - j*{1}", _re, -_im);
      else
        return string.Format("{0} + j*{1}", _re, _im);
    }
  } 
}
