﻿using System;
// using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
// using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EList
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    void OnInListBtnClick(object sender, EventArgs e)
    {
      _toDoList.Items.Add(_toDoEdit.Text);
      _toDoEdit.Text = "";
      // den Eingabefokus auf das _toDoEdit zurückholen 
      _toDoEdit.Focus();
    }

    void OnUndoBtnClick(object sender, EventArgs e)
    {

    }

    void OnDoneBtnClick(object sender, EventArgs e)
    {

    }
  }
}
