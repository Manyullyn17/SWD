﻿namespace EList
{
  partial class Form1
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      this._toDoEdit = new System.Windows.Forms.TextBox();
      this._toDoList = new System.Windows.Forms.ListBox();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this._doneList = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // _toDoEdit
      // 
      this._toDoEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this._toDoEdit.Location = new System.Drawing.Point(16, 34);
      this._toDoEdit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this._toDoEdit.Name = "_toDoEdit";
      this._toDoEdit.Size = new System.Drawing.Size(188, 34);
      this._toDoEdit.TabIndex = 0;
      // 
      // _toDoList
      // 
      this._toDoList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this._toDoList.FormattingEnabled = true;
      this._toDoList.ItemHeight = 25;
      this._toDoList.Location = new System.Drawing.Point(16, 121);
      this._toDoList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this._toDoList.Name = "_toDoList";
      this._toDoList.Size = new System.Drawing.Size(251, 579);
      this._toDoList.TabIndex = 1;
      // 
      // button1
      // 
      this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.button1.Location = new System.Drawing.Point(276, 26);
      this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(152, 44);
      this.button1.TabIndex = 2;
      this.button1.Text = "In die Liste";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new System.EventHandler(this.OnInListBtnClick);
      // 
      // button2
      // 
      this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.button2.Location = new System.Drawing.Point(276, 181);
      this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(120, 44);
      this.button2.TabIndex = 3;
      this.button2.Text = "Erledigt ->";
      this.button2.UseVisualStyleBackColor = true;
      this.button2.Click += new System.EventHandler(this.OnDoneBtnClick);
      // 
      // button3
      // 
      this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.button3.Location = new System.Drawing.Point(276, 247);
      this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(120, 44);
      this.button3.TabIndex = 4;
      this.button3.Text = "Undo <-";
      this.button3.UseVisualStyleBackColor = true;
      this.button3.Click += new System.EventHandler(this.OnUndoBtnClick);
      // 
      // _doneList
      // 
      this._doneList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this._doneList.FormattingEnabled = true;
      this._doneList.ItemHeight = 25;
      this._doneList.Location = new System.Drawing.Point(421, 121);
      this._doneList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this._doneList.Name = "_doneList";
      this._doneList.Size = new System.Drawing.Size(251, 579);
      this._doneList.TabIndex = 5;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(700, 734);
      this.Controls.Add(this._doneList);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.button1);
      this.Controls.Add(this._toDoList);
      this.Controls.Add(this._toDoEdit);
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "Form1";
      this.Text = "Form1";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox _toDoEdit;
    private System.Windows.Forms.ListBox _toDoList;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.ListBox _doneList;
  }
}

