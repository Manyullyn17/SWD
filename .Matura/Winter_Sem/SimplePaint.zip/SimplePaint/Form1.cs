﻿using System;
// using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
// using System.Linq;
using System.Text;
// using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimplePaint
{
  public partial class Form1 : Form
  {
    Brush _br = new SolidBrush(Color.Blue);

    public Form1()
    {
      InitializeComponent();
    }

    void OnPanelMouseMove(object sender, MouseEventArgs e)
    {
      _dbgLbl.Text = e.X.ToString()  + ":" +  e.Y.ToString();

      if( e.Button==MouseButtons.Left )
      {
        Graphics gr = _panel.CreateGraphics();

        gr.FillEllipse(_br, e.X, e.Y, 8, 8);
      }

    }
  }
}
