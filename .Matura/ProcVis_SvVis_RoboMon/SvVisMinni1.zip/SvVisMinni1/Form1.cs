
using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace vis1
{
  public partial class Form1 : Form
  {
    // es wird ein Array mit Pointern auf labels allokiert
    Label[] m_DispAry = new Label[3];
    SerialPort _ser;
    BinaryReaderEx _rd;
    BinaryWriter _wr;
    
    public Form1()
    {
      InitializeComponent();
      m_DispAry[0] = m_Disp1; m_DispAry[1] = m_Disp2; m_DispAry[2] = m_Disp3;
      m_SendEd.Text = "10,20";
    }
    
    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      _ser = new SerialPort("COM4", 500000, Parity.None, 8, StopBits.One);
      _ser.Open(); // hier kommt die Excepion wenn COM6 nicht da
      _rd = new BinaryReaderEx(_ser.BaseStream);
      _wr = new BinaryWriter(_ser.BaseStream);
      m_Timer1.Interval = 100; // 100msec = 10Hz
      m_Timer1.Enabled = true; // timer starten
    }
    
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
      m_Timer1.Enabled = false;
     
      base.OnFormClosing(e);
    }

    private void OnUCSendChk(object sender, EventArgs e)
    {
      if (m_uCSendChk.Checked) // 1,1  AcqOn
      {
        _wr.Write((byte)1);
        _wr.Write((byte)1);
      }
      else // 1,0  AcqOf
      {
        _wr.Write((byte)1);
        _wr.Write((byte)0);
      }
      _wr.Flush();
    }

    private void OnEmptyReceiveBuffer(object sender, EventArgs e)
    {
      
    }

    private void OnTimer(object sender, EventArgs e)
    {
      int id, knr, val;
      float valF;
      while (_ser.BytesToRead >= 3)
      {
        id = _ser.ReadByte();
        if (id >= 11 && id <= 20) // es ist ein int_16
        {
          knr = id - 10; // offset subtrahieren um auf die Kanalnummer zu kommen
          val = _rd.ReadInt16();
          m_DispAry[knr - 1].Text = val.ToString();
        }
        if (id >= 21 && id <= 30) // es ist ein float
        {
          knr = id - 20; // offset subtrahieren um auf die Kanalnummer zu kommen
          valF = _rd.ReadSingle();
          m_DispAry[knr - 1].Text = valF.ToString();
        }
        if (id == 10)
        {
          string txt = _rd.ReadCString();
          _msgList.Items.Add(txt);
        }
      }
    }

    private void OnSendEditKeyDown(object sender, KeyEventArgs e)
    {
    }
    
    void OnCommandBtn(object sender, EventArgs e)
    {
      float v1 = Convert.ToSingle(m_SendEd.Text);
      _wr.Write((byte)3); // cmd=3 SetAlpha
      _wr.Write((float)v1);
      _wr.Flush(); // Buffer leeren und senden
    }
  }
}