
using System;
using System.Collections;
using System.Text;

namespace LL_CS
{
  class Program
  {
    CsLinkedList _ll = new CsLinkedList();
    
    static void Main(string[] args)
    {
      Program pg = new Program();
      pg.Test1();
    }

    

    
    void Test1()
    {
      
    }

    
  }
}
