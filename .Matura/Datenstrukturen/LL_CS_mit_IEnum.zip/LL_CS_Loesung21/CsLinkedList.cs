
using System;
using System.Collections;
using System.Text;

namespace LL_CS
{
  class CsLink
  {
    public CsLink next;
    public object data;
    public CsLink(Object aData)
    {
      data = aData;
    }
  }
  
  class CsLinkedList : IHLContainer
  {
    #region Members
    protected CsLink _head;
    CsLink _tail;
    CsLink _iter;
    #endregion
    
    public CsLinkedList() { }

    public int Count()
    {
      return 0;
    }

    public object First()
    {
      if (_head == null) // Liste ist leer
        return null;
      _iter = _head;
      return _iter.data;
    }

    public object Next()
    {
      if (_head == null) // Liste ist leer
        return null;
      if (_iter == _tail) // Ende erreicht
        return null;
      _iter = _iter.next;
      return _iter.data;
    }

    public void AddHead(object aObj)
    {
      CsLink elem = new CsLink(aObj);
      if(_head==null ) // sonderfall Liste ist leer
      {
        _head = _tail = elem;
        return;
      }
      elem.next = _head;
      _head = elem;
    }

    public object RemoveHead()
    {
      return null;
    }

    public void AddTail(object aObj)
    {
    }

    public object RemoveTail()
    {
      return null;
    }

    public object At(int aPos)
    {
      return null;
    }

    public object Find(Object aTestObject, IComparer aCmp)
    {
      object elem = First();
      while( elem!=null )
      {
        if (aCmp.Compare(aTestObject, elem) == 0)
          return elem;
        elem = Next();
      }
      return null;
    }

    public object Remove(Object aObj)
    {
      return null;
    }

    public object RemoveAt(int aIdx)
    {
      return null;
    }

    public void InsertSorted(object aObj, IComparer aCmp)
    {
    }

    public void InsertAtPos(object aObj, int aPos)
    {
    }

    public void Print()
    {
      object elem = First();
      if( elem==null )
        Console.Write("Empty!!");
      while ( elem!=null )
      {
        Console.Write("{0} ", elem);
        elem = Next();
      }
      Console.WriteLine();
    }
  }
}
