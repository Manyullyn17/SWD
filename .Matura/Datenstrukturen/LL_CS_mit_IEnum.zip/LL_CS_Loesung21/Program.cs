
using System;
using System.Collections;
// using System.Collections.ObjectModel;
using System.Text;

namespace LL_CS
{
  class Program
  {
    // CsLinkedList _ll = new CsLinkedList();
    IHLContainer _ll = new CsLinkedList();
    // IHLContainer _ll = new CsArrayList();

    static void Main(string[] args)
    {
      Program pg = new Program();
      pg.EnumTest();
    }

    void Test1()
    {
      for (int i = 1; i <= 5; i++)
        _ll.AddHead(i);
      _ll.Print();

      // RemoveHead() Testen
      for (int i = 1; i <= 7; i++)
      {
        _ll.Print();
        _ll.RemoveHead();
      }
    }

    void Test2()
    {
      for (int i = 1; i <= 5; i++)
        _ll.AddTail(i);
      _ll.Print();

      // RemoveTail() Testen
      for (int i = 1; i <= 7; i++)
      {
        _ll.Print();
        _ll.RemoveTail();
      }
    }

    // Find testen
    void Test3()
    {
      _ll.AddHead(new Student("Franz", 10));
      _ll.AddHead(new Student("Hugo", 13));
      _ll.AddHead(new Student("Sepp", 27));
      _ll.AddHead(new Student("Sebi", 45));
      _ll.AddHead(new Student("Gerti", 23));
      _ll.Print();


      // nach CatNr suchen
      Console.WriteLine("!!!nach CatNr!!!");
      StudentCatNrCompare cmp = new StudentCatNrCompare();
      Student tstObj = new Student("", 27);
      CheckObj(tstObj, cmp);
      tstObj.m_CatNr=44; CheckObj(tstObj, cmp);
      tstObj.m_CatNr=13; CheckObj(tstObj, cmp);

      Console.WriteLine("!!!nach Name!!!");
      // nach Name suchen
      StudentNameCompare cmp2 = new StudentNameCompare();
      tstObj.m_Name="Sepp";  CheckObj(tstObj, cmp2);
      tstObj.m_Name="Michi"; CheckObj(tstObj, cmp2);
    }

    // Eine Liste mit int bef�llen
    // und das Find() testen   H�
    // und gleich string Listen ausprobieren
    void Test4()
    {

    }


    // Insert Sorted f�r Student
    // und f�r int testen
    void Test5()
    {
      IntCompare cmp = new IntCompare();

      _ll.InsertSorted(3, cmp); _ll.InsertSorted(12, cmp);
      _ll.InsertSorted(5, cmp); _ll.InsertSorted(9, cmp); // .....

      _ll.Print(); // Liste m�sste sortiert ausgegeben werden
    }

    void CheckObj(Object aTestObject, IComparer aCmp)
    {
      object elem = _ll.Find(aTestObject, aCmp);
      if (elem != null)
        Console.WriteLine("{0} found", elem);
      else
        Console.WriteLine("{0} !!NOT!! found", aTestObject);
    }

    void EnumDemo1()
    {
      int[] aryA = { 12, 13, 14, 15 };

      /* for (int i = 0; i < aryA.Length; i++)
        Console.Write("{0}", aryA[i]); */

      foreach(int val in aryA)
        Console.Write("{0} ", val);
      Console.WriteLine();

      // List<string> list7 = new List<string>();
      // foreach ( string word in list7)


    }

    void EnumTest()
    {
      CsLinkedList2 list2 = new CsLinkedList2();

      list2.AddHead("aaa"); list2.AddHead("bbb"); list2.AddHead("ccc"); list2.AddHead("ddd");

      foreach (string word in list2)
        Console.Write("{0} ", word);

      Console.WriteLine();

    }
  }
}
