﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

// Einzelne Figuren ( LineSeg ) in einer Liste speichern
// Figuren sind dann nicht mehr durch Striche verbunden

// Hausübung
//  1. Load/Store dazubauen
//  2. Farbe dazubauen
namespace SimplePaint
{
  public partial class Form1 : Form
  {
    Brush _br = new SolidBrush(Color.Blue);
    Pen _pen = new Pen(Color.Blue, 2);
    List<LineSeg> _segList = new List<LineSeg>();
    LineSeg _currSeg; // Das momentane Segment ( Figur ) an dem wir gerade zeichnen

    public Form1()
    {
      InitializeComponent();
    }

    void OnPanelMouseMove(object sender, MouseEventArgs e)
    {
      _dbgLbl.Text = e.X.ToString() + ":" + e.Y.ToString();
      // ist die linke Maustaste gedrückt ?
      if (e.Button == MouseButtons.Left)
      {
        Graphics gr = _panel.CreateGraphics();
        gr.FillEllipse(_br, e.X - 2, e.Y - 2, 4, 4);
        // den neugezeichneten Punkt im _ptAry merken
        _currSeg.AddPoint(e.Location);
      }
    }

    void OnPanelPaint(object sender, PaintEventArgs e)
    {
      Graphics gr = e.Graphics;
      foreach (LineSeg seg in _segList)
      {
        seg.Draw(gr);
      }
    }

    void OnPanelMouseUp(object sender, MouseEventArgs e)
    {
      _panel.Invalidate();
    }

    void OnMenueClear(object sender, EventArgs e)
    {
      _segList.Clear();
      _panel.Invalidate();
    }

    void OnPanelMouseDown(object sender, MouseEventArgs e)
    {
      // ein neues LineSeg erzeugen und gleich in der _segList merken
      _currSeg = new LineSeg();
      _segList.Add(_currSeg);
    }

    void OnMenueSave()
    {
      StreamWriter wr = new StreamWriter("Bild1.txt");

      foreach (LineSeg seg in _segList)
      {
        seg.WriteSeg(wr);
        wr.WriteLine("!!Ende!!");
      }
      wr.Close();
    }

    void OnMenueLoad()
    {
      StreamReader rd = new StreamReader("Bild1.txt");
      _segList.Clear(); // Bestehende Zeichnung löschen
      LineSeg seg;
      while (!rd.EndOfStream)
      {
        seg = new LineSeg();
        seg.ReadSeg(rd);
        _segList.Add(seg);
      }
      rd.Close();
    }


    class LineSeg
    {
      public List<Point> _ptList = new List<Point>();
      Pen _pen = new Pen(Color.Blue, 2);

      public void AddPoint(Point aP)
      {
        _ptList.Add(aP);
      }

      public void Draw(Graphics gr)
      {
        Point pt1, pt2;
        for (int i = 0; i < _ptList.Count - 1; i++)
        {
          pt1 = _ptList[i];
          pt2 = _ptList[i + 1];
          gr.DrawLine(_pen, pt1, pt2);
        }
      }

      public void WriteSeg(StreamWriter wr)
      {
        foreach (Point pt in _ptList)
          wr.WriteLine("{0},{1}", pt.X, pt.Y);
      }

      public void ReadSeg(StreamReader sr)
      {
        string line;
        while( !sr.EndOfStream )
        {
          line = sr.ReadLine();
          // Point lesen Code einfügen
          if (line == "!!End!!")
            break; // while Loop verlassen 
        }
      }
    }
  }
}
