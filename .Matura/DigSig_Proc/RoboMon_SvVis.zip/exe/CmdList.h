
DISP_RAW 2 1
DoCal  2  2
DISP_CAL 2 3
DISP_LINE_CTRL 2 4

AutoCal 11 100
BreakLoop 100

DispCal 4

CMODE_NONE  6  0
CMODE_SPEED 6  1
CMODE_LINE  6  4

LineON  7 1
LineOFF 7 0

Speed0 3 0 0
Speed1 3 50 50
Speed2 3 100 100
Speed3 3 200 200
Speed4 3 300 300
Speed5 3 400 400

Turn2Line 12
MazeSpeed 8 150

Rate_OFF 9 200 0
Rate1 9 200  1
Rate2 9 500  1
Rate3 9 1000 1
Rate4 9 2000 1

LabSpeed 8 150
DetCrossing 10

BreakLoop 100

