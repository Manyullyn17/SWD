
// Achtung!! Keine Kommentare innerhalb der Sections

// Com Schnittstelle
Com:  COM3 115200

// Kanal Namen
ChannelNames:
  S1
	S2
	S3
	S4

F_SAMPLE: 100

// Y-Scales
Y1Scale: -5000 5000
Y2Scale: -100 500
BarScale: 0  5000
					 
// Graphen ( Kurven )
Graphs:
	 xxx Y1
	 xxx Y1
	 xxx Y1
	 xxx Y1
	 pos Y1

