﻿
using System;
using System.Collections.Generic;
using System.Collections;
// using System.ComponentModel;
using System.Data;
using System.Drawing;
// using System.Linq;
using System.Text;
using System.Windows.Forms;



namespace Andlar
{
  public partial class FormAndlar : Form
  {
    List<GraphicObject> _grObjList = new List<GraphicObject>();
    GraphicObject _dragObj;

    public FormAndlar()
    {
      InitializeComponent();
      GraphicObject.SetDefaultColors(_panel.BackColor, Color.Red);
      _typeEd.Text = "R";
    }

    void OnPaint(object sender, PaintEventArgs e)
    {
      Graphics gr = e.Graphics;
      foreach (GraphicObject obj in _grObjList)
      {
        obj.PaintVisible(gr);
      }
    }
    
    void OnMouseDown(object sender, MouseEventArgs e)
    {
      if (_creDelChk.Checked)  // Create/Delete Modus
      {
        if (DeleteObjAt(e.Location))
        {
          _panel.Invalidate();
          return;
        }
        GraphicObject obj = null;
        if (_typeEd.Text == "R")
          obj = new GRectangle(e.X, e.Y, Color.Red);
        if (_typeEd.Text == "C")
          obj = new GCircle(e.X, e.Y, Color.Blue);

        if (obj != null)
          _grObjList.Add(obj);
        _panel.Invalidate();
      }
      else // Drag Modus
      {
        _dragObj = FindObjectAt(e.Location);
      }
    }

    void OnMouseMove(object sender, MouseEventArgs e)
    {
      if (!_creDelChk.Checked && _dragObj != null)
      {
        Graphics gr = _panel.CreateGraphics();
        _dragObj.PaintInVisible(gr);
        _dragObj.SetPos(e.Location);
        _dragObj.PaintVisible(gr);
      }
    }

    void OnMouseUp(object sender, MouseEventArgs e)
    {
      _dragObj = null;
      _panel.Invalidate();
    }
   
    public bool DeleteObjAt(Point aPos)
    {
      foreach (GraphicObject obj in _grObjList)
      {
        if (obj.HitInRadius(aPos))
        {
          _grObjList.Remove(obj);
          return true;
        }
      }
      return false;
    }

    public GraphicObject FindObjectAt(Point aPos)
    {
      foreach (GraphicObject obj in _grObjList)
      {
        if (obj.HitInRadius(aPos))
          return obj;
      }
      return null;
    }

    

    
  }
}
