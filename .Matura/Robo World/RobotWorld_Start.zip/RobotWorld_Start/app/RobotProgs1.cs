﻿using System;
using System.Threading;
using MV;

namespace RobotWorld
{
  partial class RobotProg
  {
    #region Usefull Functions
    
    void DriveDistance(double aPow, double aDist)
    {
      rb.SetV(aPow); // Motoren ein
      Vect2D start = rb.Pos;
      while (true)
      {
        // Warten bis die Simulation eine neue Pos berchnet hat
        WaitForUpdate(); 
        if (start.DistBetweenPoints(rb.Pos) > aDist)
          break;
      }
      rb.SetV(0); // Motoren aus
    }

    // Turn aPhi from current Heading
    void TurnRelAngle(double aPhi, double aRotSpeed)
    {
    }

    // aPhi must be within +/- 180°
    void TurnAbsAngle(double aPhi, double aRotSpeed)
    {
    
    }
    #endregion

    #region Programms

    void PrgAngleTest()
    {
      while (true)
      {
        WaitForUpdate();
      }
    }

    void PrgDistTest()
    {
      while (true)
      {
        DriveDistance(5, 100);
        DriveDistance(-5, 100);
      }
    }

    void PrgRectangle()
    {
      while(true)
      {
        // DriveDistance();
        // TurnRelAngle();
        WaitForUpdate();
      }
    }
    #endregion
  }
}
